import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:lakshmi_/pages/bottem_navi/notification_provider.dart';
import 'dart:io';
import 'history.dart'; // Import the history page
import 'package:provider/provider.dart'; // Import provider// Import your notification provider

class PostPage extends StatefulWidget {
  @override
  _PostPageState createState() => _PostPageState();
}

class _PostPageState extends State<PostPage> {
  File? _image;
  final ImagePicker _picker = ImagePicker();
  List<File> _postedImages = []; // Store the posted images

  Future<void> _postPhoto() async {
    final pickedFile = await _picker.pickImage(source: ImageSource.camera);
    if (pickedFile != null) {
      setState(() {
        _image = File(pickedFile.path);
      });
    }
  }

  Future<void> _selectPhotoFromAlbum() async {
    final pickedFile = await _picker.pickImage(source: ImageSource.gallery);
    if (pickedFile != null) {
      setState(() {
        _image = File(pickedFile.path);
      });
    }
  }

  void _postComplaint() {
    if (_image != null) {
      setState(() {
        _postedImages.add(_image!);
      });

      // Add a notification using the NotificationProvider
      final notificationProvider = Provider.of<NotificationProvider>(context, listen: false);
      notificationProvider.addNotification("New complaint posted!", _image!);

      // Navigate to the history page
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => HistoryPage(images: _postedImages), // Navigate to history page
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Post Page"),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            _image != null
                ? Image.file(_image!, height: 200, width: 200)
                : Text('No image selected.'),
            SizedBox(height: 30),
            ElevatedButton(
              onPressed: _postPhoto, // Directly open the camera
              child: Text("Open Camera"),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: _selectPhotoFromAlbum,
              child: Text("Select Photo from Album"),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: _postComplaint, // Add this button to post the complaint
              child: Text("Post Complaint"),
            ),
          ],
        ),
      ),
    );
  }
}
