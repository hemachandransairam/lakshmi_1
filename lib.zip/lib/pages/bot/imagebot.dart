// ignore_for_file: unused_import

import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:google_generative_ai/google_generative_ai.dart';
import 'package:image_picker/image_picker.dart';

class PhotoBot extends StatefulWidget {
  const PhotoBot({super.key});

  @override
  State<PhotoBot> createState() => _PhotoBotState();
}

class _PhotoBotState extends State<PhotoBot> {
  List<Uint8List> _images = [];
  List<String> _responses = [];
  bool _isLoading = false;

  // Set your API key and model
  static const apiKey = "AIzaSyBSMI6oYb8bBlNowN28MolnFqLFM6r9udg";
  final model = GenerativeModel(model: 'gemini-pro', apiKey: apiKey);

  Future<void> _sendMediaMessage() async {
    ImagePicker picker = ImagePicker();
    XFile? file = await picker.pickImage(source: ImageSource.gallery);

    if (file != null) {
      setState(() {
        _isLoading = true;
      });

      // Prepare the image for response generation
      File imageFile = File(file.path);
      Uint8List imageData = await imageFile.readAsBytes();
      _images.add(imageData);

      // Generate a response based on the image
      final response = await model.generateContent([
        Content.text("What can you tell me about the contents of this image?")
      ]);
      
      // Ensure response handling is robust
      String responseMessage = response.text ?? "I'm sorry, I don't understand.";
      if (responseMessage.isEmpty) {
        responseMessage = "No meaningful response generated.";
      }
      _responses.add(responseMessage); // Store the response message

      setState(() {
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("PhotoBot"),
        backgroundColor: const Color.fromARGB(255, 2, 86, 13),
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.green, Colors.white],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Expanded(
              child: ListView.builder(
                itemCount: _images.length,
                itemBuilder: (context, index) {
                  return Column(
                    children: [
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Image.memory(_images[index]),
                      ),
                      if (index < _responses.length) // Check if response exists
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Text(
                            _responses[index],
                            style: TextStyle(fontSize: 16, color: Colors.black),
                            textAlign: TextAlign.center,
                          ),
                        ),
                    ],
                  );
                },
              ),
            ),
            if (_isLoading) CircularProgressIndicator(),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _sendMediaMessage,
        child: Icon(Icons.image),
        backgroundColor: const Color.fromARGB(255, 2, 86, 13),
      ),
    );
  }
}
