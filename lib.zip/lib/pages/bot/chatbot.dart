import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:google_generative_ai/google_generative_ai.dart';
import 'package:intl/intl.dart';

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  TextEditingController _userInput = TextEditingController();
  ScrollController _scrollController = ScrollController();
  List<Message> _messages = [];
  bool _isLoading = false;

  static const apiKey = "AIzaSyBSMI6oYb8bBlNowN28MolnFqLFM6r9udg";
  final model = GenerativeModel(model: 'gemini-pro', apiKey: apiKey);

  @override
  void initState() {
    super.initState();
    _addGreetingMessage();
  }

  void _addGreetingMessage() {
    final greetingMessage = "Hello! Hi there.";
    _messages.add(Message(isUser: false, message: greetingMessage, date: DateTime.now()));
  }

  Future<void> sendMessage() async {
    final message = _userInput.text.toLowerCase(); // Convert message to lowercase

    setState(() {
      _messages.add(Message(isUser: true, message: message, date: DateTime.now()));
      _userInput.clear();
      _isLoading = true;
    });

    String responseMessage;

    // Check for predefined responses first using if-else blocks
    if (message == "who is your creator") {
      responseMessage = "My creator is senthan and its team.";
    } else if (message == "what is your name") {
      responseMessage = "My name is Lakshmi.";
    } else if (message == "how are you") {
      responseMessage = "I'm fine, what about you?";
    } else {
      // If no predefined response, get the message from the API
      final content = [Content.text(message)];
      final response = await model.generateContent(content);
      responseMessage = response.text ?? "I'm sorry, I don't understand.";
    }

    setState(() {
      _messages.add(Message(isUser: false, message: responseMessage, date: DateTime.now()));
      _isLoading = false;
      _scrollController.jumpTo(_scrollController.position.maxScrollExtent);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.green, Colors.white],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            Expanded(
              child: ListView.builder(
                controller: _scrollController,
                itemCount: _messages.length,
                itemBuilder: (context, index) {
                  final message = _messages[index];
                  return Messages(
                    isUser: message.isUser,
                    message: message.message,
                    date: DateFormat('hh:mm a').format(message.date),
                  );
                },
              ),
            ),
            if (_isLoading)
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    CircularProgressIndicator(),
                    SizedBox(width: 10),
                    Text("Bot is typing..."),
                  ],
                ),
              ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Row(
                children: [
                  Expanded(
                    flex: 15,
                    child: TextFormField(
                      style: TextStyle(color: Colors.black),
                      controller: _userInput,
                      decoration: InputDecoration(
                        filled: true,
                        fillColor: Colors.white,
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(20),
                        ),
                        labelText: 'Enter Your Message',
                        labelStyle: TextStyle(color: Colors.black54),
                      ),
                      onFieldSubmitted: (value) {
                        sendMessage();
                      },
                    ),
                  ),
                  SizedBox(width: 8),
                  IconButton(
                    padding: EdgeInsets.all(12),
                    iconSize: 30,
                    color: Color.fromARGB(255, 0, 0, 0),
                    onPressed: () {
                      sendMessage();
                    },
                    icon: Icon(Icons.send),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class Message {
  final bool isUser;
  final String message;
  final DateTime date;

  Message({required this.isUser, required this.message, required this.date});
}

class Messages extends StatelessWidget {
  final bool isUser;
  final String message;
  final String date;

  const Messages({
    super.key,
    required this.isUser,
    required this.message,
    required this.date,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(15),
      margin: EdgeInsets.symmetric(vertical: 10).copyWith(
        left: isUser ? 100 : 10,
        right: isUser ? 10 : 100,
      ),
      decoration: BoxDecoration(
        color: isUser ? Color.fromARGB(255, 0, 86, 14) : Color.fromARGB(255, 33, 196, 142),
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(20),
          bottomLeft: isUser ? Radius.circular(20) : Radius.zero,
          topRight: Radius.circular(20),
          bottomRight: isUser ? Radius.zero : Radius.circular(20),
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black12,
            blurRadius: 4,
            offset: Offset(2, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            message,
            style: TextStyle(fontSize: 16, color: isUser ? Colors.white : Colors.black),
          ),
          SizedBox(height: 4),
          Text(
            date,
            style: TextStyle(fontSize: 10, color: isUser ? Colors.white70 : Colors.black54),
          ),
        ],
      ),
    );
  }
}
