// // ignore_for_file: unused_local_variable

// import 'package:flutter/material.dart';
// import 'package:geolocator/geolocator.dart';
// import 'package:permission_handler/permission_handler.dart'; // For requesting permissions via pop-up

// class Event extends StatefulWidget {
//   const Event({super.key});

//   @override
//   _EventState createState() => _EventState();
// }

// class _EventState extends State<Event> {
//   String? _currentLocation; // To hold the latitude and longitude as a string

//   // Function to get the current location
//   Future<void> _getCurrentLocation() async {
//     LocationPermission permission;

//     // Check if location services are enabled
//     bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
//     if (!serviceEnabled) {
//       setState(() {
//         _currentLocation = 'Location services are disabled. Please enable them.';
//       });
//       return;
//     }

//     // Request location permission using permission_handler for pop-up
//     var status = await Permission.location.status;
//     if (status.isDenied) {
//       // Request permission and show pop-up
//       if (await Permission.location.request().isGranted) {
//         // Permission granted, now get the location
//         _fetchLocation();
//       } else {
//         setState(() {
//           _currentLocation = 'Location permissions are denied. Please allow access.';
//         });
//         return;
//       }
//     } else if (status.isPermanentlyDenied) {
//       setState(() {
//         _currentLocation = 'Location permissions are permanently denied. Please enable them in settings.';
//       });
//       return;
//     } else {
//       // Permission already granted, fetch location
//       _fetchLocation();
//     }
//   }

//   // Function to fetch and display the current location
//   Future<void> _fetchLocation() async {
//     Position position = await Geolocator.getCurrentPosition(
//       desiredAccuracy: LocationAccuracy.high,
//     );
//     setState(() {
//       _currentLocation =
//           'Latitude: ${position.latitude}, Longitude: ${position.longitude}';
//     });
//   }

//   @override
//   void initState() {
//     super.initState();
//     _getCurrentLocation(); // Get location when the page loads
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: const Text('Event Details'),
//         backgroundColor: Colors.blueAccent,
//       ),
//       body: Padding(
//         padding: const EdgeInsets.all(16.0),
//         child: Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             const Text(
//               'Create New Event',
//               style: TextStyle(
//                 fontSize: 24,
//                 fontWeight: FontWeight.bold,
//                 color: Colors.blueAccent,
//               ),
//             ),
//             const SizedBox(height: 20),
//             // Event Name Field
//             const Text(
//               'Event Name',
//               style: TextStyle(
//                 fontSize: 18,
//                 color: Colors.black54,
//               ),
//             ),
//             const SizedBox(height: 10),
//             TextFormField(
//               decoration: InputDecoration(
//                 hintText: 'Enter event name',
//                 border: OutlineInputBorder(
//                   borderRadius: BorderRadius.circular(10),
//                 ),
//               ),
//             ),
//             const SizedBox(height: 20),
//             // Display Latitude and Longitude
//             const Text(
//               'Event Location (Auto-fetched)',
//               style: TextStyle(
//                 fontSize: 18,
//                 color: Colors.black54,
//               ),
//             ),
//             const SizedBox(height: 10),
//             _currentLocation == null
//                 ? const CircularProgressIndicator()
//                 : Text(
//                     _currentLocation!,
//                     style: const TextStyle(
//                       fontSize: 16,
//                       color: Colors.black87,
//                     ),
//                   ),
//             const SizedBox(height: 30),
//             // Submit Button
//             Center(
//               child: ElevatedButton(
//                 onPressed: () {
//                   // Add your submit functionality here
//                 },
//                 style: ElevatedButton.styleFrom(
//                   padding: const EdgeInsets.symmetric(
//                       horizontal: 40, vertical: 15),
//                   shape: RoundedRectangleBorder(
//                     borderRadius: BorderRadius.circular(10),
//                   ),
//                   backgroundColor: Colors.blueAccent,
//                 ),
//                 child: const Text(
//                   'Submit',
//                   style: TextStyle(fontSize: 18),
//                 ),
//               ),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }

// void main() => runApp(const MaterialApp(home: Event()));
import 'package:flutter/material.dart';

class Event extends StatelessWidget {
  const Event({super.key});

  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}