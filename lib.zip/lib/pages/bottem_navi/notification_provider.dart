import 'dart:io';

import 'package:flutter/material.dart';

class NotificationProvider extends ChangeNotifier {
  List<NotificationItem> _notifications = [];

  List<NotificationItem> get notifications => _notifications;

  void addNotification(String message, File image) {
    _notifications.add(NotificationItem(message: message, image: image));
    notifyListeners();
  }
}

class NotificationItem {
  final String message;
  final File image;

  NotificationItem({required this.message, required this.image});
}
