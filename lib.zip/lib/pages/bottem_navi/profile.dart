// ignore_for_file: prefer_const_constructors

import 'package:flutter/material.dart';

class ProfilePage extends StatefulWidget {
  @override
  _ProfilePageState createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  String userName = 'John Doe'; // Replace with user's name
  String userEmail = 'johndoe@example.com'; // Replace with user's email
  String userAbout =
      'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus lacinia odio vitae vestibulum.'; // Initial about
  List<String> userInterests = [
    'Flutter',
    'Dart',
    'Programming',
    'Design',
    'Photography'
  ]; // Initial interests

  void _editProfile() async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => EditProfilePage(
          currentName: userName,
          currentEmail: userEmail,
          currentAbout: userAbout,
          currentInterests: userInterests,
        ),
      ),
    );

    if (result != null) {
      setState(() {
        userName = result['name'];
        userEmail = result['email'];
        userAbout = result['about'];
        userInterests =
            List<String>.from(result['interests']); // Update interests
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Profile"),
        backgroundColor: const Color.fromARGB(255, 2, 86, 13), // Dark green
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            children: [
              // Profile Picture
              CircleAvatar(
                radius: 70,
                backgroundImage: NetworkImage(
                  'https://via.placeholder.com/150', // Replace with user's image URL
                ),
              ),
              SizedBox(height: 16),
              // User Name
              Text(
                userName,
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 8),
              // User Email
              Text(
                userEmail,
                style: TextStyle(
                  fontSize: 16,
                  color: Colors.grey[600],
                ),
              ),
              SizedBox(height: 24),

              // Section Header
              _buildSectionHeader('About'),
              _buildSectionContent(userAbout), // Use dynamic user about text

              SizedBox(height: 24),

              // Section Header
              _buildSectionHeader('Interests'),
              _buildInterests(userInterests), // Use dynamic user interests

              SizedBox(height: 24),

              // Edit Profile Button
              ElevatedButton(
                onPressed: _editProfile,
                child: Text("Edit Profile"),
                style: ElevatedButton.styleFrom(
                  backgroundColor:
                      const Color.fromARGB(255, 2, 86, 13), // Dark green
                  padding: EdgeInsets.symmetric(horizontal: 50, vertical: 15),
                  textStyle: TextStyle(fontSize: 18),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // Helper method to build section header
  Widget _buildSectionHeader(String title) {
    return Align(
      alignment: Alignment.centerLeft,
      child: Text(
        title,
        style: TextStyle(
          fontSize: 20,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }

  // Helper method to build section content
  Widget _buildSectionContent(String content) {
    return Container(
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.grey[200], // Light grey background
        borderRadius: BorderRadius.circular(10),
      ),
      child: Text(
        content,
        style: TextStyle(fontSize: 16),
      ),
    );
  }

  // Helper method to build interests
  Widget _buildInterests(List<String> interests) {
    return Wrap(
      spacing: 8.0,
      children: interests.map((interest) {
        return Chip(
          label: Text(interest),
          backgroundColor: const Color.fromARGB(255, 2, 86, 13), // Dark green
          labelStyle: TextStyle(color: Colors.white),
        );
      }).toList(),
    );
  }
}

// Edit Profile Page
class EditProfilePage extends StatefulWidget {
  final String currentName;
  final String currentEmail;
  final String currentAbout;
  final List<String> currentInterests;

  EditProfilePage({
    required this.currentName,
    required this.currentEmail,
    required this.currentAbout,
    required this.currentInterests,
  });

  @override
  _EditProfilePageState createState() => _EditProfilePageState();
}

class _EditProfilePageState extends State<EditProfilePage> {
  late TextEditingController _nameController;
  late TextEditingController _emailController;
  late TextEditingController _aboutController;
  List<String> _interests = [];

  @override
  void initState() {
    super.initState();
    _nameController = TextEditingController(text: widget.currentName);
    _emailController = TextEditingController(text: widget.currentEmail);
    _aboutController = TextEditingController(text: widget.currentAbout);
    _interests = List<String>.from(widget.currentInterests);
  }

  @override
  void dispose() {
    _nameController.dispose();
    _emailController.dispose();
    _aboutController.dispose();
    super.dispose();
  }

  void _saveProfile() {
    Navigator.pop(context, {
      'name': _nameController.text,
      'email': _emailController.text,
      'about': _aboutController.text,
      'interests': _interests,
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Edit Profile"),
        backgroundColor: const Color.fromARGB(255, 2, 86, 13), // Dark green
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          // Add this to make the edit page scrollable
          child: Column(
            children: [
              TextField(
                controller: _nameController,
                decoration: InputDecoration(labelText: "Name"),
              ),
              TextField(
                controller: _emailController,
                decoration: InputDecoration(labelText: "Email"),
                keyboardType: TextInputType.emailAddress,
              ),
              TextField(
                controller: _aboutController,
                decoration: InputDecoration(labelText: "About"),
                maxLines: 3,
                keyboardType: TextInputType.multiline,
              ),
              SizedBox(height: 10),
              Text("Interests:"),
              Wrap(
                spacing: 8.0,
                children: _interests.map((interest) {
                  return Chip(
                    label: Text(interest),
                    backgroundColor:
                        const Color.fromARGB(255, 2, 86, 13), // Dark green
                    labelStyle: TextStyle(color: Colors.white),
                  );
                }).toList(),
              ),
              SizedBox(height: 10),
              TextField(
                decoration: InputDecoration(labelText: "Add Interest"),
                onSubmitted: (value) {
                  setState(() {
                    if (value.isNotEmpty && !_interests.contains(value)) {
                      _interests.add(value);
                    }
                  });
                },
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: _saveProfile,
                child: Text("Save"),
                style: ElevatedButton.styleFrom(
                  backgroundColor:
                      const Color.fromARGB(255, 2, 86, 13), // Dark green
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
