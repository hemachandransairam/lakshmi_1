import 'package:flutter/material.dart';
import 'package:lakshmi_/pages/history.dart'; // Import your History page

class SettingsPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Settings'),
      ),
      body: ListView(
        children: [
          ListTile(
            title: Text('Profile'),
            onTap: () {
              // Navigate to Profile Page
              Navigator.pushNamed(context, '/profile'); // Replace with your actual route
            },
          ),
          ListTile(
            title: Text('Notifications'),
            onTap: () {
              // Navigate to Notifications Page
              Navigator.pushNamed(context, '/notifications'); // Replace with your actual route
            },
          ),
          ListTile(
            title: Text('History'),
            onTap: () {
              // Navigate to History Page
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => HistoryPage(images: [])), // Pass any necessary data
              );
            },
          ),
          ListTile(
            title: Text('Privacy'),
            onTap: () {
              // Navigate to Privacy Page
              Navigator.pushNamed(context, '/privacy'); // Replace with your actual route
            },
          ),
          ListTile(
            title: Text('About'),
            onTap: () {
              // Navigate to About Page
              Navigator.pushNamed(context, '/about'); // Replace with your actual route
            },
          ),
        ],
      ),
    );
  }
}
