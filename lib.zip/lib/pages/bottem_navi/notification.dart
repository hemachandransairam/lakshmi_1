// ignore_for_file: unnecessary_null_comparison, unused_import

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'notification_provider.dart';
import 'dart:io';

class NotificationPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Notifications:"),
      ),
      body: Consumer<NotificationProvider>(
        builder: (context, notificationProvider, child) {
          return ListView.builder(
            itemCount: notificationProvider.notifications.length,
            itemBuilder: (context, index) {
              final notification = notificationProvider.notifications[index];
              return Container(
                margin: const EdgeInsets.symmetric(
                    vertical: 8, horizontal: 16), // Margin for spacing
                decoration: BoxDecoration(
                  color: Colors.grey[200], // Grey background
                  borderRadius: BorderRadius.circular(10), // Rounded corners
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.2), // Shadow color
                      offset: Offset(0, 2), // Shadow position
                      blurRadius: 4, // Shadow blur radius
                      spreadRadius: 1, // Shadow spread radius
                    ),
                  ],
                ),
                child: ListTile(
                  title: Text(notification.message),
                  // Display the image if it exists
                  subtitle: notification.image != null
                      ? Image.file(notification.image,
                          height: 100, width: 100, fit: BoxFit.cover)
                      : null,
                ),
              );
            },
          );
        },
      ),
    );
  }
}
