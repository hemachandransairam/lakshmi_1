import 'package:flutter/material.dart';
import 'package:intl/intl.dart'; // For formatting the current date
import 'package:lakshmi_/pages/bot/chatbot.dart';
import 'package:lakshmi_/pages/bot/imagebot.dart';
import 'package:lakshmi_/pages/event.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:lakshmi_/pages/post.dart'; // Import PostPage

class Homee extends StatelessWidget {
  final String userName;

  const Homee({super.key, required this.userName});

  @override
  Widget build(BuildContext context) {
    // Get the current date and day
    String currentDate = DateFormat('E, dd MMM yyyy')
        .format(DateTime.now()); // Format: Mon, 21 Oct 2024

    return Scaffold(
      appBar: AppBar(
        title: Text(
          currentDate,
          style: TextStyle(color: Colors.white), // Set date text color to white
        ),
        backgroundColor: const Color.fromARGB(255, 2, 86, 13),
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start, // Align column to start
          children: [
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Text(
                'Hello, $userName!',
                style: TextStyle(
                  fontSize: 30,
                  color: const Color.fromARGB(
                      255, 0, 0, 0), // Set "Hello" text color to black
                ),
              ),
            ),
            SizedBox(height: 10),
            // Centering the day box with circles below each day
            Center(
              child: Container(
                width: MediaQuery.of(context).size.width *
                    0.85, // Set width to 85% of screen width
                padding: EdgeInsets.symmetric(
                    vertical: 8.0, horizontal: 8.0), // Reduced padding
                decoration: BoxDecoration(
                  color: const Color.fromARGB(
                      255, 2, 86, 13), // Dark green background
                  borderRadius: BorderRadius.circular(10), // Rounded corners
                ),
                child: Row(
                  mainAxisAlignment:
                      MainAxisAlignment.center, // Center the days
                  children: [
                    _dayColumn('Mon'),
                    SizedBox(width: 5), // Smaller space between days
                    _dayColumn('Tue'),
                    SizedBox(width: 5),
                    _dayColumn('Wed'),
                    SizedBox(width: 5),
                    _dayColumn('Thu'),
                    SizedBox(width: 5),
                    _dayColumn('Fri'),
                    SizedBox(width: 5),
                    _dayColumn('Sat'),
                  ],
                ),
              ),
            ),
            SizedBox(height: 30), // Space between day box and containers
            // Horizontal scrollable row of the first two containers
            SingleChildScrollView(
              scrollDirection: Axis.horizontal, // Enable horizontal scrolling
              child: Row(
                children: [
                  _buildContainer(context, 'update photo',
                      PostPage()), // PostPage navigation
                  SizedBox(width: 10),
                  _buildContainer(
                      context, 'ask mee!', PhotoBot()), // Navigate to PhotoBot
                ],
              ),
            ),
            SizedBox(height: 30),
            // Third container below the first two
            _buildContainer(context, 'upload event', Event()), // Other page
            SizedBox(height: 30), // Space below the third container
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) => ChatScreen()), // Navigate to chatbot.dart
          );
        },
        child: Icon(Icons.chat),
        backgroundColor: const Color.fromARGB(255, 2, 86, 13), // Button color
      ),
    );
  }

  // Helper method to create a day label with a circle below it
  Widget _dayColumn(String day) {
    return Column(
      children: [
        Text(
          day, // Day label (e.g., Mon, Tue)
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
            color: Colors.white, // Set day label color to white
          ),
        ),
        SizedBox(height: 8), // Space between the day label and the circle
        Container(
          width: 30,
          height: 30,
          decoration: BoxDecoration(
            color: const Color.fromARGB(255, 255, 255, 255), // Circle color
            shape: BoxShape.circle, // Makes the container a circle
          ),
        ),
      ],
    );
  }

  // Helper method to build a container with sharp edges
  Widget _buildContainer(BuildContext context, String label, Widget page) {
    return GestureDetector(
      onTap: () async {
        var status = await Permission.storage.status;
        if (status.isDenied) {
          if (await Permission.storage.request().isGranted) {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => page),
            );
          } else {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text('Storage permission is required to proceed.'),
              ),
            );
          }
        } else if (status.isGranted) {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => page),
          );
        } else if (status.isPermanentlyDenied) {
          openAppSettings();
        }
      },
      child: Container(
        height: 150, // Small height
        width: 200, // Small width
        decoration: BoxDecoration(
          color: const Color.fromARGB(255, 2, 86, 13),
          borderRadius: BorderRadius.zero, // Sharp edges
        ),
        child: Center(
          child: Text(
            label,
            style: TextStyle(
                fontSize: 16,
                color: Colors.white), // Set container label color to white
          ),
        ),
      ),
    );
  }
}
