import 'package:flutter/material.dart';
import 'package:lakshmi_/pages/bottem_navi/about.dart';
import 'package:lakshmi_/pages/bottem_navi/notification.dart';
import 'package:lakshmi_/pages/bottem_navi/profile.dart';
import 'package:lakshmi_/pages/bottem_navi/setting.dart';
import 'package:lakshmi_/pages/bottem_navi/homee.dart';

class Home extends StatefulWidget {
  final String userName; // Add this parameter

  const Home({super.key, required this.userName}); // Require it in constructor

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  int _selectedIndex = 0;

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  static List<Widget> _pages(String userName) => <Widget>[
        Homee(userName: userName), // Pass the name to Homee widget if needed
        NotificationPage(),
        ProfilePage(),
        About(),
        SettingsPage(),
      ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Lakshmi ',
          style: TextStyle(
            fontSize: 30,
            color: const Color.fromARGB(255, 255, 255, 255),
          ),
        ), // Display username here    - Hello, ${widget.userName}
        backgroundColor: const Color.fromARGB(255, 2, 86, 13),
      ),
      body: _pages(widget.userName)[
          _selectedIndex], // Pass username to the pages if needed
      bottomNavigationBar: BottomNavigationBar(
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.notifications),
            label: 'Notifications',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: 'Profile',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.support_agent),
            label: 'about',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.settings),
            label: 'Settings',
          ),
        ],
        currentIndex: _selectedIndex,
        selectedItemColor: Colors.green,
        unselectedItemColor: Colors.grey,
        elevation: 8.0,
        onTap: _onItemTapped,
      ),
    );
  }
}
