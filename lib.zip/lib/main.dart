import 'package:flutter/material.dart';
import 'package:lakshmi_/pages/bottem_navi/notification_provider.dart';
import 'package:lakshmi_/pages/login/login.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:provider/provider.dart'; // Add this import// Import the NotificationProvider

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (context) => NotificationProvider(), // Provide the NotificationProvider
      child: MaterialApp(
        title: 'Lakshmi',
        theme: ThemeData(
          colorScheme: ColorScheme.fromSeed(seedColor: Color.fromARGB(255, 26, 110, 47)),
          useMaterial3: true,
        ),
        debugShowCheckedModeBanner: false,
        home: LoginPage(), // Home widget which includes the bottom navigation bar
      ),
    );
  }
}

class PermissionRequestExample extends StatefulWidget {
  @override
  _PermissionRequestExampleState createState() => _PermissionRequestExampleState();
}

class _PermissionRequestExampleState extends State<PermissionRequestExample> {
  @override
  void initState() {
    super.initState();
    _requestPermission();
  }

  Future<void> _requestPermission() async {
    // Check if permission is denied or permanently denied
    if (await Permission.storage.isDenied || await Permission.storage.isPermanentlyDenied) {
      // Show a dialog to ask for permission
      _showPermissionDialog();
    } else {
      // Permission already granted, proceed with your logic
    }
  }

  void _showPermissionDialog() {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('Storage Permission'),
          content: Text('This app needs access to your storage. Please allow it to continue.'),
          actions: [
            TextButton(
              onPressed: () async {
                Navigator.of(context).pop(); // Close the dialog
                // Request permission
                await Permission.storage.request();
                // Check the permission status again
                if (await Permission.storage.isGranted) {
                  // Permission granted, proceed with your logic
                }
              },
              child: Text('Allow'),
            ),
            TextButton(
              onPressed: () {
                Navigator.of(context).pop(); // Close the dialog
              },
              child: Text('Cancel'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Permission Request Example')),
      body: Center(child: Text('Requesting Storage Permission...')),
    );
  }
}
